<?php
// setting scama
$yourmail  = "x13test@skiff.com";  // your email 
$namerand = "SirPOC";  // name for file rzult *
$pass = "SirPoc123"; // pass admin panel
$botToken="6120068138:AAE4a0FPWEYahnJvM9777iAG1k16U2tuPeU"; // token bot telegram
$chatId="240837047";  // chatId telegram

?>