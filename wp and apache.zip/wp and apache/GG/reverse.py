# coding=utf-8
# Author : T.me/mylegion2
import os,sys,time,requests,re,random,colorama,ctypes
from bs4 import BeautifulSoup as sup
from multiprocessing import cpu_count
from threading import Timer
from threading import *
from threading import Thread
try:
        from queue import Queue
except:
        from Queue import Queue
from proxyscrape import create_collector, get_collector
import uuid
colorama.init(autoreset=True)
os.system('cls' if os.name=='nt' else 'clear')
def prompt(string):
        if sys.version_info.major == 3:
                return str(input(string))
        else:
                return str(raw_input(string))

# Threadss
class Worker(Thread):
        def __init__(self, tasks):
                Thread.__init__(self)
                self.tasks = tasks
                self.daemon = True
                self.start()

        def run(self):
                while True:
                        func, args, kargs = self.tasks.get()
                        try: func(*args, **kargs)
                        except Exception as e: print(e)
                        self.tasks.task_done()

class ThreadPool:
        def __init__(self, num_threads):
                self.tasks = Queue(num_threads)
                for _ in range(num_threads): Worker(self.tasks)

        def add_task(self, func, *args, **kargs):
                self.tasks.put((func, args, kargs))

        def wait_completion(self):
                self.tasks.join()
# /////////////
user_agent = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763",
        "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; KTXN)",
        "Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362",
        "Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.83 Safari/537.1",
        "Mozilla/5.0 (Linux; U; Android 2.2) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
        "Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko; googleweblight) Chrome/38.0.1025.166 Mobile Safari/535.19",
        "Mozilla/5.0 (Linux; Android 6.0.1; RedMi Note 5 Build/RB3N5C; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.91 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 7.1.2; AFTMM Build/NS6265; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.110 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 7.1.2; AFTMM Build/NS6264; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 9; SM-G960F Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.157 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 6.0.1; SM-G532G Build/MMB29T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.83 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 9; SM-G950F Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.157 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 6.0; vivo 1713 Build/MRA58K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.124 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.1805 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 7.1.1; SM-T555 Build/NMF26X; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.96 Safari/537.36",
        "Mozilla/5.0 (X11; CrOS x86_64 11895.118.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.159 Safari/537.36",
        "Mozilla/5.0 (X11; CrOS x86_64 12499.66.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.106 Safari/537.36",
        "Mozilla/5.0 (X11; CrOS x86_64 12239.92.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.136 Safari/537.36",
]
link = [
        "https://www.bing.com/search?q={}"+"&first=1&FORM=PQRE",
        "https://www.bing.com/search?q={}"+"&first=11&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=21&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=31&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=41&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=51&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=61&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=71&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=81&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=91&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=101&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=111&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=121&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=131&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=141&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=151&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=161&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=171&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=181&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=191&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=201&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=211&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=221&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=231&FORM=PORE",
        "https://www.bing.com/search?q={}"+"&first=241&FORM=PORE",
]
def check_proxy(ip):
        try:
                # try proxy http/s
                pro = dict(
                        http=ip,
                        https=ip
                )
                url_tes = 'http://httpbin.org/ip'
                r = requests.get(url_tes,proxies=pro,timeout=5)
                if 'origin' in r.text:
                        return ['ok','']
                else:
                        return ['bad']
        except:
                try:
                        # try proxy socks4
                        pro =dict(
                                http='socks4://'+ip,
                                https='socks4://'+ip
                        )
                        url_tes = 'http://httpbin.org/ip'
                        r = requests.get(url_tes,proxies=pro,timeout=5)
                        if 'origin' in r.text:
                                return ['ok','socks4://']
                        else:
                                return ['bad']
                except:
                        try:
                                # try proxy socks5
                                pro = dict(
                                http='socks5://'+ip,
                                https='socks5://'+ip
                                )
                                url_tes = 'http://httpbin.org/ip'
                                r = requests.get(url_tes,proxies=pro,timeout=5)
                                if 'origin' in r.text:
                                        return ['ok','socks5://']
                                else:
                                        return ['bad']
                        except:
                                return ['bad']
def proxy():
        list_pp = []
        # Grabber 1
        try:
                links1 = [
                                'https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all',
                                'https://api.proxyscrape.com/?request=getproxies&proxytype=socks4&timeout=10000&country=all',
                                'https://api.proxyscrape.com/?request=getproxies&proxytype=socks5&timeout=10000&country=all'
                        ]
                for link in links1:
                        nyot = requests.get(link).text.split('\n')
                        for sepong in nyot:
                                popong = sepong.split('\r')[0]
                                if popong == '':
                                        pass
                                else:
                                        if popong in list_pp:
                                                pass
                                        else:
                                                list_pp.append(popong)
        except:
                pass
        # Grabber 2
        try:
                links2 = [
                        'https://www.proxyscan.io/download?type=http',
                        'https://www.proxyscan.io/download?type=https',
                        'https://www.proxyscan.io/download?type=socks4',
                        'https://www.proxyscan.io/download?type=socks5'
                ]
                for link in links2:
                        nyot = requests.get(link).text.split('\n')
                        for sepong in nyot:
                                popong = sepong
                                if popong == '':
                                        pass
                                else:
                                        if popong in list_pp:
                                                pass
                                        else:
                                                list_pp.append(popong)
        except:
                pass
        # Grabber 3
        try:
                collector = create_collector('my-collector', ['socks4', 'socks5','http','https'])
                pr = collector.get_proxies()
                for jj in pr:
                        real_pr = '{}:{}'.format(jj.host,jj.port)
                        if real_pr in list_pp:
                                pass
                        else:
                                list_pp.append(real_pr)
        except:
                collector = get_collector('my-collector')
                collector.refresh_proxies(force=True)
                pr = collector.get_proxies()
                for jj in pr:
                        real_pr = '{}:{}'.format(jj.host,jj.port)
                        if real_pr in list_pp:
                                pass
                        else:
                                list_pp.append(real_pr)
        return list_pp
def banner():
        print('''
\033[31m        _______________________     _________
\033[32m        ___  __ )__    |__  __ \    __  ____/___  ______  _________
\033[34m        __  __  |_  /| |_  / / /    _  / __ _  / / /_  / / /_  ___/
\033[31m        _  /_/ /_  ___ |  /_/ /     / /_/ / / /_/ /_  /_/ /_(__  )
\033[33m        /_____/ /_/  |_/_____/      \____/  \__,_/ _\__, / /____/
                                                   /____/
                           \033[32mHosty \033[0m& \033[33m myl3gion
                           \033[0m(\033[31mTelegram\033[0m: \033[36mmyl3gion\033[0m)
\033[33m         _____             _       _____
\033[31m        |  __ \           | |     / ____|
\033[34m        | |  | | ___  _ __| | __ | (___   ___ __ _ _ __  _ __   ___ _ __
\033[33m        | |  | |/ _ \| '__| |/ /  \___ \ / __/ _` | '_ \| '_ \ / _ \ '__|
\033[31m        | |__| | (_) | |  |   <   ____) | (_| (_| | | | | | | |  __/ |
\033[33m        |_____/ \___/|_|  |_|\_\ |_____/ \___\__,_|_| |_|_| |_|\___|_|
                ''')
        print('-'*55)

class main:
        def __init__(self):
                self.error = 0
                try:
                        self.url = tuple(open('url.txt','r').read().splitlines())
                except:
                        self.url = tuple([])
                self.url_sqli = []
                self.gas = 0
                self.loop = 0
                self.init()
        def otw(self,dork):
                self.gas+=1
                for x in link:
                        stop = False
                        while stop == False:
                                if self.use:
                                        if sys.version_info.major == 3 and os.name == 'nt':
                                                ctypes.windll.kernel32.SetConsoleTitleW("Dork > [{}/{}] | Proxy > [{}] | Result > [{}] | Error > [{}]".format(self.gas,len(self.list_dork),len(self.list_proxy),len(self.url),self.error))
                                        pr = random.choice(self.list_proxy)
                                        cek = check_proxy(pr)
                                else:
                                        if sys.version_info.major == 3 and os.name == 'nt':
                                                ctypes.windll.kernel32.SetConsoleTitleW("Dork > [{}/{}] | Result > [{}] | Error > [{}]".format(self.gas,len(self.list_dork),len(self.url),self.error))
                                                cek = ['ok','nono']
                                if cek[0] == 'ok':
                                        if cek[1] == 'nono':
                                                pass
                                        else:
                                                prox = dict(
                                                        http=cek[1]+pr,
                                                        https=cek[1]+pr
                                                )
                                        try:
                                                ua = random.choice(user_agent)
                                                if self.use:
                                                        r = requests.get(x.replace('https','http').format(dork),headers={'User-Agent':ua},timeout=10,proxies=prox).content
                                                else:
                                                        r = requests.get(x.replace('https','http').format(dork),headers={'User-Agent':ua},timeout=10).content
                                                for i in re.findall('<h2><a href="(.*?)"',str(r)):
                                                        if '//welcome?url=' in i:
                                                                pass
                                                        else:
                                                                if '?' in i or '=' in i:
                                                                        if i in self.url_sqli:
                                                                                pass
                                                                        else:
                                                                                e = i.split('/')
                                                                                url = e[0]+'//'+e[2]
                                                                                if e[2] in self.url:
                                                                                        pass
                                                                                else:
                                                                                        #self.loop+=1
                                                                                        self.url += (e[2],)
                                                                                        self.url_sqli.append(i)
                                                                                        print("\033[94m[\033[91m{}\033[94m]\033[92m {}\033[0m".format(len(self.url),url))
                                                                                        with open('sqli.txt','a') as f:
                                                                                                f.write(i.replace('\n','')+'\n')
                                                                                        with open('url.txt','a') as tulis:
                                                                                                tulis.write(url.replace('\n','')+'\n')
                                                                else:
                                                                        e = i.split('/')
                                                                        url = e[0]+'//'+e[2]
                                                                        if e[2] in self.url:
                                                                                pass
                                                                        else:
                                                                                #self.loop+=1
                                                                                self.url += (e[2],)
                                                                                print("\033[94m[\033[91m{}\033[94m] \033[92m{}\033[0m".format(len(self.url),url))
                                                                                with open('url.txt','a') as f:
                                                                                        f.write(url+'\n')
                                                stop = True
                                        except:
                                                self.error+=1
        def update(self):
                self.timer.cancel()
                jancok = proxy()
                self.list_proxy = jancok
                self.timer = Timer(300,self.update)
                self.timer.start()
        def init(self):
                self.list_dork = open(prompt("[+] Enter list dork : "),'r').read().splitlines()
                use = prompt('[+] Use Proxy (y/n) :')
                if use == 'y' or use == 'Y':
                        self.use = True
                        print('[*] Waiting Grab Proxies....')
                        self.list_proxy = proxy()
                        print('\033[92m[#] Done, found {} proxies\033[0m'.format(len(self.list_proxy)))
                        th = prompt("[+] Threads : ")
                        self.timer = Timer(300,self.update)
                        self.timer.start()
                        if th == "":
                                th = ThreadPool(cpu_count()*2)
                        else:
                                th = ThreadPool(int(th))
                        print("-"*55)
                        for yyy in self.list_dork:
                                th.add_task(self.otw,yyy)
                        th.wait_completion()
                elif use == 'n' or use == 'N':
                        self.use = False
                        th = prompt("[+] Threads : ")
                        if th == "":
                                th = ThreadPool(cpu_count()*2)
                        else:
                                th = ThreadPool(int(th))
                        print("-"*55)
                        for yyy in self.list_dork:
                                th.add_task(self.otw,yyy)
                        th.wait_completion()
                print("-"*55)
banner()
main()
