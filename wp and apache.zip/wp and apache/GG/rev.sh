#!/bin/bash
#T.me/mylegion2

sed -i 's/\r//g' $0
limit=1; # 10 site / request
wpinstall(){
red='\e[101m'
green='\e[102m'
    if [[ `curl -s --proxy "http://ledarren511.yahoo.com:5gf29e@gate2.proxyfuel.com:2000" --url "https://api.hackertarget.com/reverseiplookup/?q=${url}" >> hasilemas.txt` =~ 'API count exceeded' ]];
        then
        echo -e "${url} LIMIT "
    else
        echo -e "${url} OK"
        cat hasilemas.txt | wc -l
        sleep 3
    fi

}
read -p "LIST TARGET : " list
sed -i 's/\r//g' ${list}
for url in `cat ${list}`; do
    ((thread=thread%limit)); ((thread++==0)) && wait
        wpinstall ${url} 
    done
        wait

